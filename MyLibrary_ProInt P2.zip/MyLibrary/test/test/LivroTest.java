package test;

import database.Conexao;
import database.LivroDAO;
import model.Livro;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.sql.Statement;

public class LivroTest {

    LivroDAO dao = new LivroDAO();

    @Before
    public void limpar() throws Exception {
        Statement stmt = Conexao.conectar().createStatement();
        stmt.execute("DROP TABLE IF EXISTS livros");
        stmt.execute("CREATE TABLE livros (id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT, autor TEXT, ano INTEGER)");
        stmt.close();
    }

    @Test
    public void testSalvar() throws Exception {
        dao.salvar(new Livro("Dom Casmurro", "Machado", 1899));
        assertEquals(1, dao.listar().size());
    }
}
