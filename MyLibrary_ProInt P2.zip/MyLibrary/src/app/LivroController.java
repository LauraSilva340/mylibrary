package app;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Livro;
import java.net.URL;
import java.util.ResourceBundle;

public class LivroController implements Initializable {

    @FXML private TextField txtTitulo;
    @FXML private TextField txtAutor;
    @FXML private TextField txtAno;
    @FXML private TableView<Livro> tabela;
    @FXML private TableColumn<Livro, Integer> colId;
    @FXML private TableColumn<Livro, String> colTitulo;
    @FXML private TableColumn<Livro, String> colAutor;
    @FXML private TableColumn<Livro, Integer> colAno;

    private ObservableList<Livro> lista = FXCollections.observableArrayList();
    private int proximoId = 1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colAutor.setCellValueFactory(new PropertyValueFactory<>("autor"));
        colAno.setCellValueFactory(new PropertyValueFactory<>("ano"));
        tabela.setItems(lista);
        
    tabela.getSelectionModel().selectedItemProperty().addListener((obs, velho, novo) -> {
            if (novo != null) {
                txtTitulo.setText(novo.getTitulo());
                txtAutor.setText(novo.getAutor());
                txtAno.setText(String.valueOf(novo.getAno()));
            }
        });
    }

    @FXML
    void handleSalvar() {
        if (txtTitulo.getText().isEmpty()) return;
        try {
            int ano = Integer.parseInt(txtAno.getText());
            Livro sel = tabela.getSelectionModel().getSelectedItem();
            if (sel == null) {
                lista.add(new Livro(proximoId++, txtTitulo.getText(), txtAutor.getText(), ano));
            } else {
                sel.setTitulo(txtTitulo.getText());
                sel.setAutor(txtAutor.getText());
                sel.setAno(ano);
                tabela.refresh();
            }
            handleLimpar();
        } catch (Exception e) {
        }
    }

    @FXML
    void handleDeletar() {
        Livro sel = tabela.getSelectionModel().getSelectedItem();
        if (sel != null) {
            lista.remove(sel);
        }
        handleLimpar();
    }

    @FXML
    void handleLimpar() {
        txtTitulo.clear();
        txtAutor.clear();
        txtAno.clear();
        tabela.getSelectionModel().clearSelection();
        txtTitulo.requestFocus();
    }
}