package app;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/view/LivroView.fxml")), 850, 500);
        try{ scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); } catch(Exception e){}
        stage.setScene(scene);
        stage.setTitle("My Library - Intermediário");
        stage.show();
    }
}