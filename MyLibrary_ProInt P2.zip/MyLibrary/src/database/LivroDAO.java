package database;

import model.Livro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivroDAO {

    public void salvar(Livro l) throws Exception {
        Connection conn = Conexao.conectar();
        PreparedStatement ps = conn.prepareStatement("INSERT INTO livros(titulo, autor, ano) VALUES(?,?,?)");
        ps.setString(1, l.getTitulo());
        ps.setString(2, l.getAutor());
        ps.setInt(3, l.getAno());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public List<Livro> listar() throws Exception {
        List<Livro> lista = new ArrayList<>();
        Connection conn = Conexao.conectar();
        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM livros");
        while (rs.next()) {
            lista.add(new Livro(rs.getInt("id"), rs.getString("titulo"), rs.getString("autor"), rs.getInt("ano")));
        }
        rs.close();
        conn.close();
        return lista;
    }

    public void deletar(int id) throws Exception {
        Connection conn = Conexao.conectar();
        conn.createStatement().execute("DELETE FROM livros WHERE id=" + id);
        conn.close();
    }

    public void atualizar(Livro l) throws Exception {
        Connection conn = Conexao.conectar();
        PreparedStatement ps = conn.prepareStatement("UPDATE livros SET titulo=?, autor=?, ano=? WHERE id=?");
        ps.setString(1, l.getTitulo());
        ps.setString(2, l.getAutor());
        ps.setInt(3, l.getAno());
        ps.setInt(4, l.getId());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
