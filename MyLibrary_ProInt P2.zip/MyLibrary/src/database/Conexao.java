package database;

import java.sql.*;

public class Conexao {

    public static Connection conectar() throws Exception {
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:biblioteca.db");
        Statement stmt = conn.createStatement();
        stmt.execute("CREATE TABLE IF NOT EXISTS livros (id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT, autor TEXT, ano INTEGER)");
        stmt.close();
        return conn;
    }
}
