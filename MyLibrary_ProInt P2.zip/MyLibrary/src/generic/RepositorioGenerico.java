package generic;

import java.util.ArrayList;
import java.util.List;

public class RepositorioGenerico<T> {

    private List<T> lista = new ArrayList<>();

    public void adicionar(T item) {
        lista.add(item);
    }

    public List<T> listar() {
        return lista;
    }

    public void remover(T item) {
        lista.remove(item);
    }
}
